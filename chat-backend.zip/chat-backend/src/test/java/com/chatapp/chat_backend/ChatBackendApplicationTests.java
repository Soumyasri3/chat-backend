package com.chatapp.chat_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
